# 🔧 ARGOS Patch Notes — v1.4.0 → v1.4.1

> Дата: март 2026  
> Патч закрывает все пункты аудита финального релиза.

---

## Что в этом архиве

| Файл | Действие | Куда положить |
|------|----------|---------------|
| `hardware_intel.py` | Переименован из `ardware_intel.py` | Корень репозитория (заменить старый) |
| `crypto_monitor.py` | Исправлен TODO: Telegram подключён | Корень репозитория (заменить) |
| `cleanup_root.py` | Скрипт очистки дублей | Корень репозитория (запустить 1 раз) |
| `src/interface/legacy/__init__.py` | Папка для старых GUI | `src/interface/legacy/` |
| `tests/test_crypto_monitor.py` | 16 тестов CryptoSentinel | `tests/` |
| `tests/test_budding_manager.py` | 10 тестов BuddingManager | `tests/` |
| `tests/test_jarvis_engine.py` | 10 тестов JarvisEngine | `tests/` |
| `tests/test_messenger_bridges.py` | 14 тестов WhatsApp/Slack/Router | `tests/` |
| `tests/test_hardware_intel.py` | 8 тестов hardware_intel | `tests/` |

---

## Порядок применения

### Шаг 1 — Скопировать файлы
```bash
# Положи файлы из архива в нужные места (см. таблицу выше)
cp hardware_intel.py /путь/к/репо/hardware_intel.py
cp crypto_monitor.py /путь/к/репо/crypto_monitor.py
cp cleanup_root.py /путь/к/репо/cleanup_root.py
cp tests/* /путь/к/репо/tests/
mkdir -p /путь/к/репо/src/interface/legacy
cp src/interface/legacy/__init__.py /путь/к/репо/src/interface/legacy/
```

### Шаг 2 — Удалить старый файл с опечаткой
```bash
cd /путь/к/репо
git rm ardware_intel.py
git add hardware_intel.py
```

### Шаг 3 — Запустить очистку корня
```bash
python cleanup_root.py
```
Скрипт автоматически:
- Удалит файлы-дубли из корня (оставив копии в `src/`)
- Переместит `kivy_1gui.py`, `kivy_ma.py`, `main_kivy.py` → `src/interface/legacy/`
- Удалит patch-файлы (`life_support_patch.py` и т.д.)

### Шаг 4 — Переместить Kivy GUI в legacy (если cleanup не сделал это)
```bash
mkdir -p src/interface/legacy
git mv kivy_1gui.py src/interface/legacy/
git mv kivy_ma.py src/interface/legacy/
git mv main_kivy.py src/interface/legacy/
# kivy_gui.py остаётся как главный GUI
```

### Шаг 5 — Проверить импорты hardware_intel во всём проекте
```bash
grep -r "ardware_intel" . --include="*.py"
# Если что-то нашлось — заменить на hardware_intel
```

### Шаг 6 — Запустить новые тесты
```bash
pytest tests/test_crypto_monitor.py -v
pytest tests/test_hardware_intel.py -v
pytest tests/test_budding_manager.py -v
pytest tests/test_jarvis_engine.py -v
pytest tests/test_messenger_bridges.py -v
```

### Шаг 7 — Коммит
```bash
git add -A
git commit -m "fix: rename ardware_intel, fix crypto Telegram, cleanup root, add 58 tests"
git push
git tag v1.4.1
git push --tags
```

---

## Что исправлено

### ✅ ardware_intel.py → hardware_intel.py
- Исправлена опечатка в имени файла
- Улучшено форматирование кода (PEP 8)
- Добавлена обработка `ram.used // 1024**2` (была синтаксическая нечёткость)

### ✅ crypto_monitor.py — Telegram подключён
- Удалён TODO-комментарий
- Реализован `_send_alert()` с поддержкой трёх интерфейсов:
  - `bot.send_message(msg)` — основной
  - `bot.send(msg)` — альтернативный
  - `bot.notify(msg)` — legacy
- Добавлена обработка ошибок отправки (не крашит поток)
- `start_loop()` теперь показывает статус Telegram в ответе
- Добавлен `logging` вместо `print`
- Поток назван `"crypto-sentinel"` для отладки

### ✅ Новые тесты (+58 тестов → покрытие ~22%)
| Модуль | Тестов |
|--------|--------|
| CryptoSentinel | 16 |
| BuddingManager | 10 |
| JarvisEngine | 10 |
| WhatsApp/Slack/Router bridges | 14 |
| hardware_intel | 8 |
| **Итого** | **58** |

### ✅ Структура
- `src/interface/legacy/` создана для старых GUI-файлов
- `cleanup_root.py` — автоматизирует очистку дублей

---

## Следующие шаги (v1.5.0)

- [ ] Проверить и закрыть 2 открытых PR
- [ ] Переименовать `ghost_c2.py` → `node_c2_protocol.py` или удалить
- [ ] Переименовать `network_shadow.py` → `network_stealth.py` (если нужно)
- [ ] React-фронтенд вместо Streamlit
- [ ] Публикация документации через MkDocs (mkdocs.yml уже есть)
- [ ] Довести покрытие тестов до 30%+
